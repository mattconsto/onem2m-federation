from sense_hat import SenseHat

print(SenseHat().get_pressure())